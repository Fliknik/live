# -*- coding: utf-8 -*-
# from odoo import http


# class CreateInvoiceReplica(http.Controller):
#     @http.route('/create_invoice_replica/create_invoice_replica/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/create_invoice_replica/create_invoice_replica/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('create_invoice_replica.listing', {
#             'root': '/create_invoice_replica/create_invoice_replica',
#             'objects': http.request.env['create_invoice_replica.create_invoice_replica'].search([]),
#         })

#     @http.route('/create_invoice_replica/create_invoice_replica/objects/<model("create_invoice_replica.create_invoice_replica"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('create_invoice_replica.object', {
#             'object': obj
#         })
